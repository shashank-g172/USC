Shashank Gowdagiri
1956-0195-02
sgowdagi@usc.edu

List of files:
booksales.xsd
booksales.xsl
booksales.xml
q1.xquery
q2.xquery
q3.xquery
q4.xquery
q5.xquery
readme file(this)