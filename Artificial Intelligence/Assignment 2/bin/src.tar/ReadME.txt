Shashank G
1956-0195-02

There are two files for submission. The first one called helloWorld.java and the second class is Custom.java. 

I have used a Class.forName in the main of the first class, I am not sure if I needed to do it with packages.

As per the last update, Task3 is still incomplete, and I am specifying exactly how to run the program. The executable is the first line of the program, as per the requirements, and the program should run fine for the first task, and for the second.

