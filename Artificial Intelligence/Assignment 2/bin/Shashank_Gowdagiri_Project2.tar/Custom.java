

public class Custom {

	private Custom leftChild=null;
	private Custom rightChild=null;
	private String onlyString;
	
	public String getOnlyString() {
		return onlyString;
	}
	public void setOnlyString(String onlyString) {
		this.onlyString = onlyString;
	}
	public Custom getRightChild() {
		return rightChild;
	}
	public void setRightChild(Custom rightChild) {
		this.rightChild = rightChild;
	}
	
	public Custom getLeftChild() {
		return leftChild;
	}
	public void setLeftChild(Custom leftChild) {
		
			this.leftChild = leftChild;
	}
	
	
}
