#include "types.h"
#include "globals.h"
#include "kernel.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/cpuid.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/tty/virtterm.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"

GDB_DEFINE_HOOK(boot)
GDB_DEFINE_HOOK(initialized)
GDB_DEFINE_HOOK(shutdown)

static void      *bootstrap(int arg1, void *arg2);
static void      *idleproc_run(int arg1, void *arg2);
static kthread_t *initproc_create(void);
static void      *initproc_run(int arg1, void *arg2);
static void       hard_shutdown(void);
static void	 *testfunc(int arg1, void *arg2); /*test thread*/
static context_t bootstrap_context;

int x = 1; /*global integer*/
kmutex_t mutex; /*global mutex*/
/**
 * This is the first real C function ever called. It performs a lot of
 * hardware-specific initialization, then creates a pseudo-context to
 * execute the bootstrap function in.
 */
void
kmain()
{
        GDB_CALL_HOOK(boot);

        dbg_init();
        dbgq(DBG_CORE, "Kernel binary:\n");
        dbgq(DBG_CORE, "  text: 0x%p-0x%p\n", &kernel_start_text, &kernel_end_text);
        dbgq(DBG_CORE, "  data: 0x%p-0x%p\n", &kernel_start_data, &kernel_end_data);
        dbgq(DBG_CORE, "  bss:  0x%p-0x%p\n", &kernel_start_bss, &kernel_end_bss);

        page_init();

        pt_init();
        slab_init();
        pframe_init();

        acpi_init();
        apic_init();
        intr_init();

        gdt_init();

        /* initialize slab allocators */
#ifdef __VM__
        anon_init();
        shadow_init();
#endif
        vmmap_init();
        proc_init();
        kthread_init();

#ifdef __DRIVERS__
        bytedev_init();
        blockdev_init();
#endif

        void *bstack = page_alloc();
        pagedir_t *bpdir = pt_get();
        KASSERT(NULL != bstack && "Ran out of memory while booting.");
        context_setup(&bootstrap_context, bootstrap, 0, NULL, bstack, PAGE_SIZE, bpdir);
        context_make_active(&bootstrap_context);

        panic("\nReturned to kmain()!!!\n");
}

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
bootstrap(int arg1, void *arg2)
{
        pt_template_init();
	proc_t *idleproc;
	idleproc = proc_create("idle");
	kthread_t *idlethr;
	idlethr = kthread_create(idleproc, idleproc_run, 0, NULL);
	curproc = idleproc;
	curthr = idlethr;	
	dbg(DBG_TEST, "Starting the idle process by switching context to idle thr\n");
	context_make_active(&(idlethr->kt_ctx));
        panic("weenix returned to bootstrap()!!! BAD!!!\n");
        return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;
        
	/* create init proc */
        kthread_t *initthr = initproc_create();

        init_call_all();
        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */

        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);

        /* Now wait for it*/
        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);

#ifdef __MTP__
        kthread_reapd_shutdown();
#endif


#ifdef __VFS__
        /* Shutdown the vfs: */
        dbg_print("weenix: vfs shutdown...\n");
        vput(curproc->p_cwd);
        if (vfs_shutdown())
                panic("vfs shutdown FAILED!!\n");

#endif

        /* Shutdown the pframe system */
#ifdef __S5FS__
        pframe_shutdown();
#endif

        dbg_print("\nweenix: halted cleanly!\n");
        GDB_CALL_HOOK(shutdown);
        hard_shutdown();
        return NULL;
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
static kthread_t *
initproc_create(void)
{
        /*create the init process with PID = 1, init process should contain a thread which begins execution in initproc_run()*/
		proc_t *initproc;
		initproc = proc_create ("init");
		kthread_t *initthr;
		initthr = kthread_create(initproc, initproc_run, 0, NULL);
		/*return a pointer to the newly created thread which will execute initproc_run when it begins executing*/
		return initthr;
}

/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/bin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
initproc_run(int arg1, void *arg2)
{
        /*NOT_YET_IMPLEMENTED("PROCS: initproc_run");*/
	int status, i, retpid;
	kmutex_init(&mutex);
	dbg(DBG_TEST, "FINALLY RUNNING INIT PROCESS\n");
	dbg(DBG_TEST, "INIT PROCESS CREATING FIVE CHILD PROCESSES AND THREADS\n");
	proc_t *test_p[5];
	kthread_t *test_t[5];
	for (i = 0; i < 5; i++) {
		test_p[i] = proc_create("testproc");
		test_t[i] = kthread_create(test_p[i], testfunc, i+1, NULL);    
		sched_make_runnable(test_t[i]);
	}

	/*UNCOMMENT THIS CALL TO TEST proc_kill_all() */
	/*proc_kill_all();*/

	/*TEST CASE FOR OUT OF ORDER TERMINATION OF CHILD PROCESSES*/
	/*	
	kthread_cancel(test_t[1], (void*)0);
	kthread_cancel(test_t[3], (void*)0);
	*/	

	/*NORMAL USE OF do_waitpid()*/
	for (i = 0; i < 5; i++) {
		retpid = do_waitpid(-1, 0, &status);
		dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	} 
	
	/*EDGE CASES OF do_waitpid()*/

	/*calling do_waitpid on child processes in random order */
	
	/*
	retpid = do_waitpid(6, 0, &status);
	dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	retpid = do_waitpid(4, 0, &status);
	dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	retpid = do_waitpid(3, 0, &status);
	dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	retpid = do_waitpid(5, 0, &status);
	dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	retpid = do_waitpid(7, 0, &status);
	dbg(DBG_TEST, "do_waitpid returned in init process: terminated child's pid is:%d\n", retpid);
	*/

	
	
	
	/*WRONG OPTIONS USED IN do_waitpid()*/
	/*
	retpid = do_waitpid(-1, 4, &status);
	retpid = do_waitpid(-3, 0, &status);
	*/
	
	dbg(DBG_TEST, "init process cleaned up all its child processes\n");
	dbg(DBG_TESTPASS, "FINAL VALUE of x: %d\n", x);
	return NULL;
}

/*test thread, tries to lock mutex and increments global x 100 times*/

static void* testfunc (int arg1, void *arg2) {
	int i;
	/*each thread checks if its cancelled, if true the calls kthread_exit()*/
	if(curthr->kt_cancelled == 1) {
		dbg(DBG_TEST, "Test thread with PID:%d, sees that its been cancelled, calls kthread_exit()\n", curproc->p_pid);
		kthread_exit(0);	
	}
	dbg(DBG_TEST, "Running test thread with PID:%d\n", curproc->p_pid);
	kmutex_lock(&mutex);
	dbg(DBG_TEST, "Test thread with PID:%d LOCKED mutex and now incrementing x\n", curproc->p_pid);
	for( i = 0; i < 100; i++) {
		
		/*UNCOMMENT THIS CONDITION TO TEST MUTEX WORKING*/
		/*we explicitly make the current thread yield the processor, other threads find the mutex locked*/		
		
		if(i == 50) {
			sched_make_runnable(curthr);
			sched_switch();	
		}
		
	
		x = x + 1;
	}
	dbg(DBG_TEST, "Test thread with PID:%d UNLOCKING mutex\n", curproc->p_pid);
	kmutex_unlock(&mutex);
	dbg(DBG_TESTPASS, "Test thread with PID:%d ends\n", curproc->p_pid);
	return (void*)0;
}


/**
 * Clears all interrupts and halts, meaning that we will never run
 * again.
 */
static void
hard_shutdown()
{
#ifdef __DRIVERS__
        vt_print_shutdown();
#endif
        __asm__ volatile("cli; hlt");
}
